function login() {
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;
  const msg = document.getElementById("message");

  // Username dan password yang diperbolehkan
  const validUser = "admin";
  const validPass = "12345";

  if (user === validUser && pass === validPass) {
    msg.style.color = "green";
    msg.innerText = "Login Berhasil!";

    // Arahkan ke halaman lain (opsional)
    setTimeout(() => {
      window.location.href = "https://example.com";
    }, 1500);
  } else {
    msg.style.color = "red";
    msg.innerText = "Username atau Password salah!";
  }
}
